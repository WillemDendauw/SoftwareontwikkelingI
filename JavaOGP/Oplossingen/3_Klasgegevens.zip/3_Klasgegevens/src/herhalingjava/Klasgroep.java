package herhalingjava;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author Marleen
 */
public class Klasgroep {
    
    private Persoon[] personen; // de naam van de array was vroeger 'studenten';  
                                // wijzig dit naar 'personen' om vergissingen te voorkomen

    public Klasgroep(String bestandsnaam) throws FileNotFoundException {
        try (Scanner sc = new Scanner(new File(bestandsnaam))) {
            personen = new Persoon[sc.nextInt()];   // OOK AAN TE PASSEN!!
            sc.nextLine();
            Student.initTesten(sc.nextLine(), sc.nextLine());  //verwerk de twee eerste lijnen
            
            int nr = 0;
            while (sc.hasNextLine()) {
                String lijn = sc.nextLine();
                Scanner sc2 = new Scanner(lijn); //een volledige lijn gebruiken voor de tweede Scanner-variabele
                sc2.useDelimiter(";");                    //delimiter instellen
                sc2.useLocale(Locale.FRENCH);             //noodzakelijk voor indienen op Dodona
                String naam = sc2.next();                 //de drie deeltjes ophalen
                int leeftijd = sc2.nextInt();
                String richting = sc2.next();
                if (richting.equals("")) {
                    richting = "???";
                }

                if (sc2.hasNextDouble()) {                 //werkt op DOdona enkel als Local is ingesteld
                    Student st = new Student(naam, leeftijd, richting);  //student maken              
                    String lijnpunten = sc2.nextLine().substring(1);     //substring met punten                    
                    st.addPunten(lijnpunten);
                    personen[nr] = st;
                } else {
                    personen[nr] = new Persoon(naam, leeftijd);
                }
                sc2.close();
                nr++;
            }
        }
    }

    public int aantalGeslaagdenVoor(String test, String richting) {
        int tel = 0;
        for (Persoon p : personen) //alle elementen in de array zijn ingevuld  
        {
            if (p instanceof Student) {
                Student st = (Student) p;
                if (st.getRichting().equals(richting) && st.isGeslaagdVoor(test)) {
                    tel++;
                }
            }
        }
        return tel;
    }

    public Student geefBesteStudent() {

        Student beste = null;
        int score = 0;

        for (Persoon p : personen) {
            if (p instanceof Student) {
                Student st = (Student) p;
                int s = st.geefTotaal();
                if (s > score) {
                    score = s;
                    beste = st;
                }
            }
        }
        return beste;
    }
    
// nieuwe methodes    
    public int aantalDocenten() {
        int tel=0;
        for (Persoon p : personen) {
            if (! (p instanceof Student)) {
                tel++;
            }
        }
        return tel;
    }

    public Persoon kiesPersoon(){
        int kies = (int)(Math.random()*personen.length);
        return personen[kies];
    }
    
    public Persoon kiesDocent()
    {
        Persoon p = kiesPersoon();
        while (p instanceof Student)
        {
            p = kiesPersoon();
        }
        return p;
    }
    
}
