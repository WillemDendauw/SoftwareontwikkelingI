/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vervoer;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Marleen
 */
public class Voertuigen {

    private List<IVoertuig> voertuigen; //mag ook ArrayList zijn

    /*   private Trein[] treinen;
    private int aantalTreinen;

    //toevoegen voor deel 2
    private Truck[] trucks;
    private int aantalTrucks;
     */
    public Voertuigen(String bestandsnaam) throws FileNotFoundException {
        voertuigen = new ArrayList();
        Scanner sc = new Scanner(new File(bestandsnaam));
        while (sc.hasNext()) {  // gebruik GEEN hasNextLine(); dat geeft (soms) fouten bij
            // het inlezen van de laatste lijnen van het bestand
            String regel = sc.nextLine();
            try (Scanner sc2 = new Scanner(regel)) {
                sc2.useDelimiter(";");
                String type = sc2.next();
                if (type.equals("TREIN")) {   //een trein
                    int aantalPassagiers = sc2.nextInt();
                    int snelheid = sc2.nextInt();
                    String internationaal = sc2.next();
                    voertuigen.add(new Trein(aantalPassagiers, snelheid, internationaal));
                }
                if (type.equals("TR")) {  //een gewone truck
                    int gewichtLeeg = sc2.nextInt();
                    int gewichtLading = sc2.nextInt();
                    voertuigen.add(new Truck(gewichtLeeg, gewichtLading));
                }
                if (type.equals("MT")) {  //een zware truck       
                    int gewichtLeeg = sc2.nextInt();
                    int gewichtLading = sc2.nextInt();
                    int maxLading = sc2.nextInt();
                    voertuigen.add(new MaxGewichtTruck(gewichtLeeg, gewichtLading, maxLading));

                }
                sc2.close();
            }
        }
        sc.close(); //kan ook met try-clausule - zonder close
    }

    public int aantalTreinen() {
        int telTreinen = 0;
        for (IVoertuig voertuig : voertuigen) {
            if (voertuig instanceof Trein) {
                telTreinen++;
            }
        }
        return telTreinen;
    }

    public int aantalOverladen() {
        int tel = 0;
        for (IVoertuig voertuig : voertuigen) {
            if (voertuig instanceof MaxGewichtTruck) {
                MaxGewichtTruck zwaretruck = (MaxGewichtTruck) voertuig;
                if (zwaretruck.isOverladen()) {
                    tel++;
                }
            }
        }
        return tel;
    }

    public Trein geefSnelsteTrein() {
        int max = 0;
        Trein snelste = null;
        for (IVoertuig voertuig : voertuigen) {
            if (voertuig instanceof Trein) {
                Trein trein = (Trein) voertuig;
                if (trein.getMaxSnelheid() > max) {
                    max = trein.getMaxSnelheid();
                    snelste = trein;
                }
            }
        }
        return snelste;
    }

    public int maxSnelheidTreinen() {
        Trein snelsteTrein = geefSnelsteTrein();
        return snelsteTrein.getMaxSnelheid();
    }

    public IVoertuig kiesVoertuig() {
        Random r = new Random();
        return voertuigen.get(r.nextInt(voertuigen.size()));
    }

    public Truck kiesTruck() {
        IVoertuig v = kiesVoertuig();
        while (!(v instanceof Truck)) {
            v = kiesVoertuig();
        }
        return (Truck) v;
    }

    public int aantalMaxGewichtTruck() {
        int tel = 0;
        for (IVoertuig voertuig : voertuigen) {
            if (voertuig instanceof MaxGewichtTruck) {
                tel++;
            }
        }
        return tel;
    }

    //uit vorig labo - niet noodzakelijk voor deze oefening
     public int tel(String soort, String bestandsnaam) throws FileNotFoundException {

        int tel = 0;
        try (Scanner sc = new Scanner(new File(bestandsnaam))) {
            while (sc.hasNextLine()) {
                String regel = sc.nextLine();
                
                if (regel.indexOf(soort + ";") == 0) { //(*)
                    tel++;
                }
            }
            return tel;
        }
    }
     
    public void schrijfTypeVanTreinen(String bestandsnaam) throws FileNotFoundException {
        Scanner sc = new Scanner(new File(bestandsnaam));
        while (sc.hasNextLine()) {
            String regel = sc.nextLine();
            String[] woorden = regel.split(";");
            if (woorden[0].equals("TREIN")) {
                System.out.println(woorden[woorden.length - 1]);
            }
        }
       
        sc.close();
    }
   
}
