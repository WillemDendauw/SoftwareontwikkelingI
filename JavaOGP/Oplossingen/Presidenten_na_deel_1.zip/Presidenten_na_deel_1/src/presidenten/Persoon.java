package presidenten;


/**
 *
 * @author tiwi
 */
public class Persoon {
    
    private String naam;
    private String periode;
    
    // vul aan waar nodig
    public Persoon(String naam, String periode){
        this.naam = naam;
        this.periode = periode;
    }
    
    public String getNaam() {
        return naam;
    }
    
    @Override
    public String toString(){
        return naam+" "+periode;
    }
}
