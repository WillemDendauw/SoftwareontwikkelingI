/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presidenten;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Leen Brouns
 */
public class Republiek {

    private President[] presidenten;
    private Random random = new Random();

    public Republiek(String bestandsnaam) throws FileNotFoundException {
        Scanner sc = new Scanner(new File(bestandsnaam));
        presidenten = new President[sc.nextInt()];
        sc.nextLine();
        int i = 0;
        while (sc.hasNext()) {
            Scanner sc2 = new Scanner(sc.nextLine());
            sc2.useDelimiter(";");
            presidenten[i] = new President(sc2.next(), sc2.next(), sc2.next(), sc2.next(), sc2.nextInt());
            i++;
        }
        sc.close();
    }

    public President kiesWillekeurigePresident() {
        return presidenten[random.nextInt(presidenten.length)];
    }

    public President getPresidentMetLangstAmbtsperiode() {
        if (presidenten.length == 0) {
            return null;
        }
        President langstAanDeMacht = presidenten[0];
        for (int i = 1; i < presidenten.length; i++) {
            if(langstAanDeMacht.getAmbtsduur() <= presidenten[i].getAmbtsduur()){
                langstAanDeMacht = presidenten[i];
            }
        }
        return langstAanDeMacht;
    }
}
