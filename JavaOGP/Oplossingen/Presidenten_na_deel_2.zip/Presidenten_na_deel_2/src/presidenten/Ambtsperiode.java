package presidenten;

import java.util.Objects;

/**
 *
 * @author tiwi
 */
public class Ambtsperiode {
    private String start;
    private String stop;
    private int duur;
    
    public Ambtsperiode(String start, String stop, int duur){
        this.start = start;
        this.stop = stop;
        this.duur = duur;
    }

    public int getDuur(){
        return duur;
    }
    
    @Override
    public String toString(){
        return "["+duur+" periode(s), van "+start+" tot "+stop+"]";
    }
    // vul aan indien nodig 
}
