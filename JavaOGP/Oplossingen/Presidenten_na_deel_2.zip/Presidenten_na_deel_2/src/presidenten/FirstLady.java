/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presidenten;

/**
 *
 * @author Leen Brouns
 */
public class FirstLady extends Persoon implements BewonerPresidentieelPaleis{

    private President echtgenoot;
    
    public FirstLady(String naam, String periode, President echtgenoot) {
        super(naam, periode);
        this.echtgenoot = echtgenoot;
    }

    @Override
    public String toString(){
        return super.toString()+" (echtgenoot is "+echtgenoot.getNaam()+")";
    }
    
    
    @Override
    public Ambtsperiode getAmbtsperiode() {
        return echtgenoot.getAmbtsperiode();
    }
    
}
