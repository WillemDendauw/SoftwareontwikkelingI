/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presidenten;

/**
 *
 * @author Leen Brouns
 */
public class Huisdier {
    protected String naam;
    protected String soort;
    protected Persoon baasje;
    
    public Huisdier(String naam, String soort, Persoon baasje){
        this.naam = naam;
        this.soort = soort;
        this.baasje = baasje;
    }

    public String getSoort() {
        return soort;
    }
    
    @Override
    public String toString() {
        return naam + " (" + soort + ", baasje is "+baasje.getNaam()+")";
    }
}
