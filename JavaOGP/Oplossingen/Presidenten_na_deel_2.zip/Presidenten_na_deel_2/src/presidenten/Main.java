package presidenten;

import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author tiwi
 */
public class Main {

    public static void main(String[] args) {
        
        try {
            Republiek republiek = new Republiek("presidenten_met_hun_gevolg.csv");
            
            System.out.println("Alle info uit het bestand: "+republiek);
            
            System.out.println("\nAantal honden dat al in Witte Huis woonde: "+republiek.aantalHuisdierenVanSoort("dog"));
            System.out.println("\nAantal paarden dat al in Witte Huis woonde: "+republiek.aantalHuisdierenVanSoort("horse"));
            
            System.out.println("\nAlle presidenten:\n"+republiek.allePresidenten());
            System.out.println("\nAlle first ladies:\n"+republiek.alleFirstLadies());
            System.out.println("\nAlle presidential pets:\n"+republiek.allePresidentialPets());
            
            
        } catch (FileNotFoundException ex) {
            System.out.println("bestand niet gevonden");
        }

    }

}
