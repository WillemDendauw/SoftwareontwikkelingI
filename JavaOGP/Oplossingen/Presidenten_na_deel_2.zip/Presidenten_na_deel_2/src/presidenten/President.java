/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presidenten;

/**
 *
 * @author Leen Brouns
 */
public class President extends Persoon implements BewonerPresidentieelPaleis{
    private Ambtsperiode ambtsperiode;
    
    public President(String naam, String periode, String start, String stop, int aantal){
        super(naam,periode);
        ambtsperiode = new Ambtsperiode(start,stop,aantal);
    }
    
    @Override
    public String toString(){
        return super.toString()+" "+ambtsperiode;
    }
    
    // vraag f
    public int getAmbtsduur(){
        return ambtsperiode.getDuur();
    }
    
    // DEEL 2
    public Ambtsperiode getAmbtsperiode(){
        return ambtsperiode;
    }
}
