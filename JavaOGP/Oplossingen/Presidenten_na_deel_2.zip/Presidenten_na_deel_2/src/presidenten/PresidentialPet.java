/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presidenten;

/**
 *
 * @author Leen Brouns
 */
public class PresidentialPet extends Huisdier implements BewonerPresidentieelPaleis{
    
    public PresidentialPet(String naam, String soort, President baasje) {
        super(naam, soort, baasje);
    }
    
    @Override
    public Ambtsperiode getAmbtsperiode() {
        return ((President)baasje).getAmbtsperiode();
    }
    
}
