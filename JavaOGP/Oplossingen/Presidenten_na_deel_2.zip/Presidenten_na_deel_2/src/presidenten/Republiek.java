/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presidenten;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Leen Brouns
 */
public class Republiek {

    /*
    // DIT MAG WEG, IS VAN DEEL 1
    
    private President[] presidenten;
    private Random random = new Random();

    public Republiek(String bestandsnaam) throws FileNotFoundException {
        Scanner sc = new Scanner(new File(bestandsnaam));
        presidenten = new President[sc.nextInt()];
        sc.nextLine();
        int i = 0;
        while (sc.hasNext()) {
            Scanner sc2 = new Scanner(sc.nextLine());
            sc2.useDelimiter(";");
            presidenten[i] = new President(sc2.next(), sc2.next(), sc2.next(), sc2.next(), sc2.nextInt());
            i++;
        }
        sc.close();
    }

    public President kiesWillekeurigePresident() {
        return presidenten[random.nextInt(presidenten.length)];
    }

    public President getPresidentMetLangstAmbtsperiode() {
        if (presidenten.length == 0) {
            return null;
        }
        President langstAanDeMacht = presidenten[0];
        for (int i = 1; i < presidenten.length; i++) {
            if(langstAanDeMacht.getAmbtsduur() <= presidenten[i].getAmbtsduur()){
                langstAanDeMacht = presidenten[i];
            }
        }
        return langstAanDeMacht;
    }
     */
    private List<BewonerPresidentieelPaleis> bewoners;
    private Map<String, President> presidentMetNaam;

    public Republiek(String bestandsnaam) throws FileNotFoundException {

        bewoners = new ArrayList<>();
        presidentMetNaam = new HashMap<>();

        President president = null;
        Scanner sc = new Scanner(new File(bestandsnaam));
        while (sc.hasNext()) {
            Scanner sc2 = new Scanner(sc.nextLine());
            sc2.useDelimiter(";");
            String type = sc2.next();
            if (type.equals("President")) {
                president = new President(sc2.next(), sc2.next(), sc2.next(), sc2.next(), sc2.nextInt());
                bewoners.add(president);
                presidentMetNaam.put(president.getNaam(), president);
            } else if (type.equals("FirstLady")) {
                bewoners.add(new FirstLady(sc2.next(), sc2.next(), president));
            } else if (type.equals("PresidentialPet")) {
                bewoners.add(new PresidentialPet(sc2.next(), sc2.next(), president));
            }
            sc2.close();
        }
        sc.close();
    }

    @Override
    public String toString() {
        String res = "";
        for (BewonerPresidentieelPaleis b : bewoners) {
            res += "\n" + b;
        }
        return res;
    }

    public int aantalHuisdierenVanSoort(String soort) {
        int aantal = 0;
        for (BewonerPresidentieelPaleis b : bewoners) {
            if (b instanceof Huisdier && ((Huisdier) b).getSoort().equals(soort)) {
                aantal++;
            }
        }
        return aantal;
    }

    public List<President> allePresidenten() {
        List<President> list = new ArrayList<>();
        for (BewonerPresidentieelPaleis b : bewoners) {
            if (b instanceof President) {
                list.add((President) b);
            }
        }
        return list;
    }

    public List<FirstLady> alleFirstLadies() {
        List<FirstLady> list = new ArrayList<>();
        for (BewonerPresidentieelPaleis b : bewoners) {
            if (b instanceof FirstLady) {
                list.add((FirstLady) b);
            }
        }
        return list;
    }

    public List<PresidentialPet> allePresidentialPets() {
        List<PresidentialPet> list = new ArrayList<>();
        for (BewonerPresidentieelPaleis b : bewoners) {
            if (b instanceof PresidentialPet) {
                list.add((PresidentialPet) b);
            }
        }
        return list;
    }

}
