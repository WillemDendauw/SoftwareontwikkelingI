STUDENTENBEHEER
________________________________________________________________________________
public class Persoon implements Serializable {
    private final String voornaam;
    private final String achternaam;
    private String adres;
    private int postcode;
    private String gemeente;
    private final Date geboortedatum;

    public Persoon(String voornaam, String naam, String adres, int postcode, String gemeente, Date geboortedatum) {
        this.voornaam = voornaam;
        this.achternaam = naam;
        this.adres = adres;
        this.postcode = postcode;
        this.gemeente = gemeente;
        
        // Hier wordt de parameter Date gekloond. Omdat 'geboortedatum' een object
        // is, moet je afwegen wat je wil:
        // -  als je zeker misbruik van de constructor wil vermijden 
        //    (in de unittest 'testConstructorPersoon' proberen we dit misbruik uit),
        //    dan moet je van elke parameter een kloon maken
        //    (behalve voor parameters van primitieve types of immutable objects.)
        // -  in de praktijk merk je dat het aanpassen van een datum niet evident is
        //    (je moet al via getTime() en setTime()), dus zaken 'per ongeluk' aanpassen
        //    zal niet snel gebeuren.
        if (geboortedatum == null) {
            this.geboortedatum = null;
        } else {
            this.geboortedatum = (Date) geboortedatum.clone();
        }
    }

    public Persoon(Persoon p) {
        this(p.voornaam, p.achternaam, p.adres, p.postcode, p.gemeente, p.geboortedatum);
    }

    public String getVoornaam() {
        return voornaam;
    }

    public String getAchternaam() {
        return achternaam;
    }

    // Stond niet in de opgave; toegevoegd
    // om een extra test te laten lopen (zie unittest 'testConstructorPersoon').
    public Date getGeboortedatum() {
        return (Date) geboortedatum.clone();
    }

    @Override
    public String toString() {
        return voornaam + " " + achternaam;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 11 * hash + Objects.hashCode(this.voornaam);
        hash = 11 * hash + Objects.hashCode(this.achternaam);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Persoon other = (Persoon) obj;
        if (!Objects.equals(this.voornaam, other.voornaam)) {
            return false;
        }
        if (!Objects.equals(this.achternaam, other.achternaam)) {
            return false;
        }
        return true;
    }
} 
________________________________________________________________________________

public class Student extends Persoon {    

    private Set<Cursus> curriculum;
    // Bewaarde je ook het aantal studiepunten?
    // Let op met het dubbel bewaren van informatie! 
    // (Uit het curriculum kan het aantal studiepunten ook afgeleid worden,
    // dus dubbele info.)
    // Eens de dubbele informatie gecorrumpeerd is, krijg je dat nooit meer goed!

    public final static int MAXAANTALSTUDIEPUNTEN = 20;  // eigenlijk 60; voor testdoeleinden lager!!

    public Student(String voornaam, String naam, String adres, int postcode, String gemeente, Date geboortedatum) {
        super(voornaam, naam, adres, postcode, gemeente, geboortedatum);
        curriculum = new HashSet();
    }
    
    // De kopieconstructor maakt een diepe kopie,
    // dus ook van alle cursussen zal een kopie gemaakt worden.
    // Gebruik de kopieconstructor dus NIET IN de klasse StudentenDAO,
    // want dan eindig je met veel te veel kopies van cursussen.
    // (Bekijk de opmerking in StudentenDAO over de 30 + 15 + 200 objecten.)
    // De kopieconstructor zal alleen nuttig zijn bij het schrijven van 
    // de getter-methodes in StudentenDAO:
    //    getStudent(...)
    //    getDocent(...)
    //    getCursus(...)
    // maar die methodes worden niet INTERN in de klasse StudentenDAO
    // opgeroepen; die zijn er enkel ten behoeve van de gebruikers 
    // van de klasse StudentenDAO.
    public Student(Student andereStudent){
        super(andereStudent);
        curriculum = new HashSet();
        for(Cursus cursus : andereStudent.curriculum){
            curriculum.add(cursus.clone());
        }
    }

    public void schrijfInVoorVak(Cursus cursus) throws FoutBijInschrijving {
        // Indien curriculum dit vak al bevat, of totaal aantal studiepunten
        // overschreden zou worden: niet inschrijven maar fout opwerpen.
        // De vraag 'contains' impliceert natuurlijk dat je de methode
        // 'equals' hebt voor de klasse Cursus (en dus ook de methode hashCode).
        if (curriculum.contains(cursus)) {
            throw new FoutBijInschrijving("al ingeschreven voor vak " + cursus.getNaam());
        }
        int puntenCursus = cursus.getAantalStudiepunten();
        int puntenReedsOpgenomen = this.getAantalStudiepunten();
        if (puntenCursus + puntenReedsOpgenomen > MAXAANTALSTUDIEPUNTEN) {
            throw new FoutBijInschrijving("aantal studiepunten is al "
                    + puntenReedsOpgenomen + "; daar kunnen er geen "
                    + puntenCursus + " meer bij.");
        }
        curriculum.add(cursus);
        cursus.voegStudentToe(this); // zorg in de methode 'voegStudentToe' dat er geen
        // oneindige loop mogelijk is
    }

    // Hieronder werd gekozen om het returntype te veranderen van Cursus[] (zie gegeven klassendiagram)
    // naar Set<Cursus>. Dat zijn ontwerpbeslissingen, die jullie misschien anders genomen hebben.
    //
    // Omdat we willen vermijden dat er via deze weg aan de cursussen geprutst kan
    // worden (bvb. setDocent(...)), geven we hier een set van kopies terug.
    // Ook weer een ontwerpbeslissing die je misschien anders nam; 
    // maar oefen je zeker in het teruggeven van kopies van objecten!
    public Set<Cursus> getCurriculum() {
        Set<Cursus> kopie = new HashSet<>();
        for (Cursus c : curriculum) {
            kopie.add(c.clone());
        }
        return kopie;
    }

    public int getAantalStudiepunten() {
        int pt = 0;
        for (Cursus c : curriculum) {
            pt += c.getAantalStudiepunten();
        }
        return pt;
    }

    @Override
    public String toString() {
        String str = "";
        for (Cursus c : curriculum) {
            str += c.getNaam() + " -";
        }
        return "student " + super.toString() + str;
    }

    // Geen hashCode en equals nodig; 
    // je erft die van de bovenklasse over.
    // Een Docent met naam Jef Klaassen en een Student met naam Jef Klaassen
    // zullen als verschillende Persoon herkend worden!
    // (Ga na...)
}        
________________________________________________________________________________
        
public class Docent extends Persoon{
    private Set<Cursus> cursussen;

    public Docent(String voornaam, String naam){
        super(voornaam,naam,null,0,null,null);
        cursussen = new HashSet();
    }
    
    public Docent(Docent andereDocent){
        super(andereDocent);
        cursussen = new HashSet();
        for(Cursus cursus : andereDocent.cursussen){
            cursussen.add(cursus.clone());
        }        
    }
        
    public void addCursus(Cursus cursus){
        cursussen.add(cursus);
        if(!this.equals(cursus.getDocent())){ // draai de operandi niet om; NullPointerException!!
            cursus.setDocent(this);
        }
    }
    
    // hier wordt een kopie van de cursussen teruggegeven
    public Cursus[] getCursussen(){        
        Cursus[] cc = new Cursus[cursussen.size()];
        int i=0;
        for(Cursus c : cursussen){
            cc[i++] = c.clone();
        }
        return cc;  
    }
    // Indien je een ondiepe kopie van de cursussen wil teruggeven, dan zou je
    //     return cursussen.toArray(new Cursus[0]);
    // schrijven.
    
    
    public boolean geeftCursus(Cursus c){
        return cursussen.contains(c);
    }
    
    @Override
    public String toString(){
        String str = "docent " + super.toString() +" ";
        for(Cursus c : cursussen){
            str += c.getNaam()+" / ";
        }
        return str;
    }

}        
________________________________________________________________________________            
        
public class Cursus implements Serializable, Cloneable {
    private final String naam;
    private final int studiejaar;
    private Docent titularis; 
    private final int aantalStudiepunten;
    private Set<Student> studenten;
    String cursuscode;
    
    // In deze oplossing is er sprake van een 'cursuscode'.
    // Zie het txt-bestand: 
    // in het txt-bestand van het gegeven STARTproject stond er geen code 
    // vermeld bij een cursus; in dit OPLOSSINGENproject is dat nu wel zo.
    // Als je de implementatie deed zonder cursuscode:
    // dan zijn cursussen (bijvoorbeeld) gelijk als hun naam, studiejaar en 
    // aantalStudiepunten gelijk zijn. Neem hier, in samenspraak met je
    // pairprogram-maatje, een gefundeerde beslissing en volg die dan consequent.
    // (hashCode en equals moeten wel op elkaar afgestemd zijn!)
    public Cursus(String naam, int studiejaar, int aantalStudiepunten, String code){
        this.naam = naam;
        this.studiejaar = studiejaar;
        this.titularis = null;
        this.aantalStudiepunten = aantalStudiepunten;
        this.studenten = new HashSet<>();
        this.cursuscode = code;
    }
    // BELANGRIJK om NullPointerExceptions te vermijden:
    // in de constructor initialiseer je ALLE instantievariabelen!!
    // Zo mis je geen 'new ....'.
    // TIP voor op een test: komt er 'NullPointerException' bij de output, ga dan
    //                       eerst alle constructoren af.
    //                       Initialiseerde je alle instantievariabelen?
              
    
    public void setDocent(Docent docent) {
        titularis = docent;
        if(!titularis.geeftCursus(this)){
            titularis.addCursus(this);
        }
    }
    // Als een cursus gegeven wordt door een bepaalde docent,
    // moet niet alleen die cursus dat weten. Ook de docent onthoudt dit.
    // Daarom bovenstaande if-structuur. (Zonder 'if' zou je in een oneindige
    // loop verzeild raken.)

    
    // De getter geeft een ondiepe kopie; je kan hier dus gegevens van de 
    // docent gaan wijzigen.
    // Alternatief: een diepe kopie via return new Docent(titularis); 
    // --> dan moet je wel een kopieconstructor aanmaken bij Docent.
    public Docent getDocent() {
        return titularis;
    }
    
    // Allicht is de naam van de docent opvragen ook voldoende
    // voor bepaalde toepassingen;
    // dan kan je de gevaarlijke getter achterwege laten.
    // (Strings zijn immutable objects; daar krijg je dus automatisch een kopie van.)
    public String geefNaamDocent(){
        return titularis.getVoornaam()+" "+titularis.getAchternaam();
    }
    
    
    // Heeft 'Student' een hashCode (en equals)?
    // Anders zal onderstaande methode niet het gewenste effect hebben.
    public void voegStudentToe(Student student) throws FoutBijInschrijving{
        studenten.add(student);
        if(!student.getCurriculum().contains(this)){
            student.schrijfInVoorVak(this);
        }
    }
    // MERK OP
    // Omdat we 'dubbele informatie' bijhouden
    // (een student houdt verwijzingen bij naar zijn cursussen;
    //   een cursus houdt verwijzingen bij naar zijn studenten)
    // is het belangrijk om ervoor te zorgen dat alle informatie goed
    // op elkaar afgestemd is. 
    // Bij databanken noemt dit afstemmen "normaliseren van de databank";
    // dat is een cursus op zich.
    // VOORDELEN VAN DUBBELE INFORMATIE BIJHOUDEN:
    //    - zaken zijn sneller opgezocht 
    //      (waar het bij databanktoepassingen dikwijls om draait)
    // NADELEN  VAN DUBBELE INFORMATIE BIJHOUDEN:
    //    - meer geheugenplaats nodig (al is het enkel voor 'referenties naar',     
    //                                 de objecten zelf worden niet dubbel bewaard)
    //    - beter opletten bij toevoegen van informatie
    
    public int getAantalStudiepunten() {
        return aantalStudiepunten;
    }
    
    public String getNaam(){
        return naam;
    }

    // Implementatie van hashCode en equals zijn ZEKER nodig,
    // anders zou een student zich tien keer voor dezelfde cursus
    // kunnen inschrijven; de hashSet 'curriculum' van de klasse 'Student'
    // zou niet doorhebben dat het om eenzelfde cursus gaat.
    //
    // In jullie oplossing werd er allicht voor naam, studiejaar en aantalStudiepunten
    // gekozen. Is prima.
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.naam);
        hash = 59 * hash + Objects.hashCode(this.cursuscode);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cursus other = (Cursus) obj;
        if (!Objects.equals(this.naam, other.naam)) {
            return false;
        }
        if (!Objects.equals(this.cursuscode, other.cursuscode)) {
            return false;
        }
        return true;
    }
    
    
    @Override
    public String toString(){
        String str = naam + " ("+studiejaar+"e jaar; "+aantalStudiepunten+" studiepunten; titularis ";
        if(titularis == null){
            str += "null; "+studenten.size()+" studenten)";
        }
        else{
            str += titularis.getAchternaam()+"; "+studenten.size()+" studenten)";
        }
        return str;
    }
    
    
    @Override
    public Cursus clone(){
        try {
            return (Cursus)super.clone();
        } catch (CloneNotSupportedException ex) {
            return null;
        }
    }
}
________________________________________________________________________________
        
public class StudentenDAO implements Serializable {
// DAO staat voor Data Access Object;
// deze klasse geeft je toegang tot verschillende objecten tegelijk.
//    
// LET OP!
// Het is de bedoeling dat een object van deze klasse 
//     van elke student slechts één exemplaar bewaart;
//     van elke docent slechts één exemplaar bewaart;
//     van elke cursus slechts één exemplaar bewaart.
// Dus als er 200 studenten, 15 docenten en 30 cursussen zijn,
// dan zal er slechts 200 + 15 + 30 keer een 'new' object van de gepaste
// klasse gecreëerd worden en in de instantievariabelen (drie mappen)
// bewaard worden.
//
// De onderlingen relaties tussen studenten, cursussen en docenten
// worden dan door middel van REFERENTIES (verwijzingen) gelegd;
// NIET door een kopie van objecten te creëren.
//
// Merk op dat de getters wel kopieën creëren, maar dat hoort ook zo voor 
// een getter. Een buitenstaander zou anders aan de cruciale interne informatie
// wijzigingen kunnen aanbrengen.
//
// Maar dan moet je wel opletten bij het hoofdprogramma.
// Als je een student wenst in te schrijven voor een vak (bvb Wiskunde I), 
// en dus daarvoor eerst de student opvraagt aan het DAO-object
// om de student in te schrijven voor die cursus, dan zal er intern in het DAO-object
// niets gewijzigd zijn (je werkt immers met een KOPIE van de student en allicht
// ook met een kopie van de cursus, als je die via getter verkreeg). 
// Beter: je geeft het DAO-object de opdracht een bepaalde
// student in te schrijven voor een bepaalde cursus.
// Dat vraagt dus een extra methode, die nog niet voorzien was in het klassendiagram.    
    
    private Map<String, Student> studenten; // voornaam+" "+naam als key !!
    private Map<String, Docent> docenten;
    private Map<String, Cursus> cursussen;

    public StudentenDAO(String bestandMetCursussen) throws FileNotFoundException {
        studenten = new HashMap<>();
        docenten = new HashMap<>();
        cursussen = new HashMap<>();

        Scanner sc = new Scanner(new File(bestandMetCursussen));
        while (sc.hasNext()) {
            String regel = sc.nextLine();
            //System.out.println("REGEL "+regel); // methode om fouten te vinden
            // bij inlezen van bestand !!!
            // nl. SCHRIJF UIT WAT JE INLEEST.
            Scanner sc2 = new Scanner(regel);
            sc2.useDelimiter(";");
            int jaar = sc2.nextInt();
            String titel = sc2.next();
            String naamTitularis = sc2.next();
            int aantalPtn = sc2.nextInt();
            String code = sc2.next();
            Cursus cursus = new Cursus(titel, jaar, aantalPtn, code);
            int plaatsSpatie = naamTitularis.indexOf(" ");
            Docent docent = new Docent(naamTitularis.substring(0, plaatsSpatie).trim(),
                    naamTitularis.substring(plaatsSpatie).trim());

            if (!docenten.containsKey(naamTitularis.toLowerCase().trim())) {
                docenten.put(naamTitularis.toLowerCase().trim(), docent);
            }
            docenten.get(naamTitularis.toLowerCase().trim()).addCursus(cursus);

            if (!cursussen.containsKey(titel)) {
                cursussen.put(titel, cursus);
            }
            cursussen.get(titel).setDocent(docenten.get(naamTitularis.toLowerCase().trim()));

        }

    }

    public Student getStudent(String naam) {
        Student st = studenten.get(naam.toLowerCase().trim());
        if(st == null){
            return null;
        }
        return new Student(st);
    }

    public Docent getDocent(String naam) {
        Docent d = docenten.get(naam.toLowerCase().trim());
        if(d == null){
            return null;
        }
        return new Docent(d);
    }

    public Cursus getCursus(String naam) {
        return cursussen.get(naam).clone();
    }

    public Cursus[] getCursussenVanDocent(String naam) {
        Docent d = docenten.get(naam.toLowerCase().trim());
        Cursus[] c = d.getCursussen(); // dit bevat al een kopie van de cursussen
        return c;
    }

    public void addStudent(Student student) {
        studenten.put((student.getVoornaam() + " " + student.getAchternaam()).toLowerCase(), student);
    }
    
    public void schrijfStudentInVoorCursus(String studentenNaam, String cursusNaam) throws FoutBijInschrijving{
        if(!studenten.containsKey(studentenNaam)){
            throw new FoutBijInschrijving("student met naam "+studentenNaam+" niet gevonden.");
        }
        if(!cursussen.containsKey(cursusNaam)){
            throw new FoutBijInschrijving("cursus met naam "+cursusNaam+" niet gevonden.");
        }
        studenten.get(studentenNaam).schrijfInVoorVak(cursussen.get(cursusNaam));
    }

    // zorgt dat alle cursusnamen onder elkaar weergegeven worden;
    // is nuttig in het hoofdprogramma
    public String getCursussenToString() {
        String antwoord = "";
        for (String str : cursussen.keySet()) {
            antwoord += str + "\n";
        }
        return antwoord;
    }

    @Override
    public String toString() {
        String str = "DOCENTEN";
        for (String docent : docenten.keySet()) {
            str += "\n" + docent + " ---> " + docenten.get(docent);
        }
        str += "\nSTUDENTEN";
        for (String st : studenten.keySet()) {
            str += "\n" + st + " ---> " + studenten.get(st);
        }
        str += "\nVAKKEN";
        str += ("-----------size van cursussen is " + cursussen.size());
        for (String st : cursussen.keySet()) {
            str += "\n" + st + " ---> " + cursussen.get(st);
        }
        return str;
    }

}       
________________________________________________________________________________
        
public class Studentenbeheer {

    private static StudentenDAO dao;
    private static Scanner sc = new Scanner(System.in);

    // De code die hieronder staat, voorziet nog wat extra's;
    // nl. de gebruiker geeft op de commandolijn weer of hij wil
    // 'resetten' (alle vorige geserialiseerde gegevens worden gewist, en er wordt
    //             opgestart vanaf het tekst-bestand dat de gebruiker meegeeft
    //             op diezelfde commandolijn).
    // Indien de gebruiker niets ingeeft op de commandolijn, wordt er
    // voortgewerkt op de geserialiseerde gegevens uit de vorige run van
    // het programma.
    public static void main(String[] args) {
        
        dao = null;
        try {
            if (args.length > 1 && args[0].equalsIgnoreCase("reset")) {
                System.out.println("Ik reset het programma, en start vanaf het bestand " + args[1] + ".");
                initialiseerDAO(true, args[1]);
            } else if (args.length == 0) {
                System.out.println("Ik ga voort met de gegevens die ik opsloeg na de vorige run van het programma.");
                initialiseerDAO(false, "");
            }

            overlegMetGebruiker();  // het eigenlijke programmaverloop

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            if (dao != null) {
                try {
                    schrijfGeserialiseerdeVersieWeg();
                } catch (IOException ex) {
                    System.out.println("Iets foutgelopen bij het wegschrijven van alle gegevens... "
                            + "een volgende run kan problemen opleveren :-/");
                }
            }
        }

    }

    public static void overlegMetGebruiker() {
        int keuze = toonMenu();
        while (keuze != 4) {
            if (keuze == 1) {
                docentZoeken();
            } else if (keuze == 2) {
                studentZoeken();
            } else if (keuze == 3) {
                studentInschrijven();
            }
            keuze = toonMenu();
        }
        sc.close();
    }

    private static void initialiseerDAO(boolean reset, String bestandsnaam) throws FileNotFoundException, Exception {

        // twee mogelijkheden: 
        // (1) 'reset' door bestand met cursussen en docenten in te lezen,
        // (2) geserialiseerde StudentenDAO uit bestand halen                 
        if (reset) {
            dao = new StudentenDAO(bestandsnaam);
        } else {
            leesGeserialiseerdeVersieIn();
        }
    }

    private static void leesGeserialiseerdeVersieIn() throws Exception {
        try {
            File opslag = new File("studentenDAOopslagplaats.txt");
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(opslag));
            dao = (StudentenDAO) in.readObject();
        } catch (IOException ex) {
            throw new Exception("Je vraagt me niet om te resetten "
                    + "(commandolijn zou dan 'reset bestandsnaam.txt' bevatten), "
                    + "\nmaar er liep iets mis met de opslag van vorige runs...\n"+ex.getMessage());
        } catch (ClassNotFoundException ex) {
            throw new Exception("Je vraagt me niet om te resetten "
                    + "(commandolijn zou dan 'reset bestandsnaam.txt' bevatten), "
                    + "\nmaar er liep iets mis met de opslag van vorige runs...\n"+ex.getMessage());
        }
    }

    private static void schrijfGeserialiseerdeVersieWeg() throws IOException {
        File opslag = new File("studentenDAOopslagplaats.txt");
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(opslag))) {
            out.writeObject(dao);
        }
    }

    private static String vraagInfo(String boodschap){
        System.out.println(boodschap+": ");
        return sc.nextLine();
    }
    
    private static Date vraagGeboortedatum(){
        Date datum;
        String datumString = vraagInfo("Geboortedatum (dd-MM-yyyy)");
        try {
            datum = new SimpleDateFormat("dd-MM-yyyy").parse(datumString);
        } catch (ParseException ex) {
            System.out.println("Verkeerde geboortedatum");
            datum = vraagGeboortedatum();
        }
        return datum;
    }
    
    private static void studentInschrijven() {
        System.out.println("Deel I: Personalia");
        System.out.println("");
        
        String voornaam = vraagInfo("Voornaam");
        String naam = vraagInfo("Naam");

        Student student = dao.getStudent(voornaam + " " + naam); // Dit is een kopie;
                   // werk niet verder met methodes van deze student als je
                   // hem/haar wil inschrijven! Stel de vraag aan dao!!
                   // Dit zal je enkel merken als je een student eerst inschrijft voor
                   // twee vakken, terugkeert naar het keuzemenu,
                   // en nadien diezelfde student wil inschrijven voor
                   // nog een extra vak. Dat extra vak zal nooit in zijn curriculum
                   // verschijnen als je met deze kopie verder werkt.

        // enkel indien de student nog niet in het systeem zat, worden
        // zijn gegevens opgevraagd
        if (student == null) {
            Date geboortedatum = vraagGeboortedatum();
            String adres = vraagInfo("Adres");
            String strPostcode = vraagInfo("Postcode");
            int postcode = -1;
            while (postcode == -1) {
                try {
                    postcode = Integer.parseInt(strPostcode); // zou je in methode moeten verpakken!
                    if (postcode != 0 && !(postcode >= 1000 && postcode <= 9999)) {
                        postcode = -1;
                        throw new NumberFormatException();
                    }
                } catch (NumberFormatException e) {
                    strPostcode = vraagInfo("Postcode (0 indien onbekend)");
                }
            }
            String gemeente = vraagInfo("Gemeente");
            student = new Student(voornaam, naam, adres, postcode, gemeente, geboortedatum);
            dao.addStudent(student);
        }
        System.out.println("");
        System.out.println("Deel II: Curriculum");
        String cursusNaam = vraagInfo("Geef de naam van een cursus (lege string om te stoppen)");
        while (!cursusNaam.equals("")) {
            Cursus cursus = dao.getCursus(cursusNaam);
            if (cursus != null) {
                try {
                    //student.schrijfInVoorVak(cursus); //'student' is een kopie; dus dit gaat niets uithalen!
                    dao.schrijfStudentInVoorCursus(voornaam+" "+naam,cursusNaam);
                } catch (FoutBijInschrijving e) {
                    System.out.println(e.getMessage());
                }
            } else {
                System.out.println("Deze cursus bestaat niet; dus inschrijving ging niet door.");
                System.out.println("Kies uit: " + dao.getCursussenToString());
            }            
            cursusNaam = vraagInfo("Geef de naam van een cursus (lege string om te stoppen)");
        }

    }

    private static void studentZoeken() {
        String naam = vraagInfo("Geef de naam van een student (voornaam spatie achternaam)").trim().toLowerCase();
        Student student = dao.getStudent(naam);
        if (student != null) {
            System.out.println(naam + " is ingeschreven voor:");
            for (Cursus oo : student.getCurriculum()) {
                System.out.println(oo.getNaam());
            }
        } else {
            System.out.println("Deze student werd niet gevonden; onze excuses.");
        }
    }

    private static int toonMenu() {
        System.out.println("\n\nMaak een keuze:");
        System.out.println("");
        System.out.println("1. een docent zoeken");
        System.out.println("2. een student zoeken");
        System.out.println("3. een student inschrijven");
        System.out.println("4. stoppen");
        System.out.print("\nKeuze:  ");
        Scanner sc = new Scanner(System.in);
        int keuze;
        try{
            keuze = sc.nextInt();
        }
        catch(InputMismatchException e){
            System.out.println("Verkeerde invoer ("+e.getMessage()+"): ");
            keuze = toonMenu();
        }
        return keuze;
    }

    private static void docentZoeken() {
        String naam = vraagInfo("Geef de naam van een docent (voornaam, spatie, achternaam)").trim().toLowerCase();
        Docent docent = dao.getDocent(naam);
        if (docent != null) {
            System.out.println(naam + " geeft de volgende cursussen: ");
            for (Cursus cursus : docent.getCursussen()) {
                System.out.println(cursus.getNaam());
            }
        } else {
            System.out.println("Deze docent werd niet gevonden; onze excuses.");
        }
    }

}        
________________________________________________________________________________
________________________________________________________________________________