package studentenbeheer;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 *
 * @author tiwi
 */
public class Cursus implements Serializable, Cloneable {
    private final String naam;
    private final int studiejaar;
    private Docent titularis; 
    private final int aantalStudiepunten;
    private Set<Student> studenten;
    String cursuscode;
    
    // In deze oplossing is er sprake van een 'cursuscode'.
    // Zie het txt-bestand: 
    // in het txt-bestand van het gegeven STARTproject stond er geen code 
    // vermeld bij een cursus; in dit OPLOSSINGENproject is dat nu wel zo.
    // Als je de implementatie deed zonder cursuscode:
    // dan zijn cursussen (bijvoorbeeld) gelijk als hun naam, studiejaar en 
    // aantalStudiepunten gelijk zijn. Neem hier, in samenspraak met je
    // pairprogram-maatje, een gefundeerde beslissing en volg die dan consequent.
    // (hashCode en equals moeten wel op elkaar afgestemd zijn!)
    public Cursus(String naam, int studiejaar, int aantalStudiepunten, String code){
        this.naam = naam;
        this.studiejaar = studiejaar;
        this.titularis = null;
        this.aantalStudiepunten = aantalStudiepunten;
        this.studenten = new HashSet<>();
        this.cursuscode = code;
    }
    // BELANGRIJK om NullPointerExceptions te vermijden:
    // in de constructor initialiseer je ALLE instantievariabelen!!
    // Zo mis je geen 'new ....'.
    // TIP voor op een test: komt er 'NullPointerException' bij de output, ga dan
    //                       eerst alle constructoren af.
    //                       Initialiseerde je alle instantievariabelen?
              
    
    public void setDocent(Docent docent) {
        titularis = docent;
        if(!titularis.geeftCursus(this)){
            titularis.addCursus(this);
        }
    }
    // Als een cursus gegeven wordt door een bepaalde docent,
    // moet niet alleen die cursus dat weten. Ook de docent onthoudt dit.
    // Daarom bovenstaande if-structuur. (Zonder 'if' zou je in een oneindige
    // loop verzeild raken.)

    
    // De getter geeft een ondiepe kopie; je kan hier dus gegevens van de 
    // docent gaan wijzigen.
    // Alternatief: een diepe kopie via return new Docent(titularis); 
    // --> dan moet je wel een kopieconstructor aanmaken bij Docent.
    public Docent getDocent() {
        return titularis;
    }
    
    // Allicht is de naam van de docent opvragen ook voldoende
    // voor bepaalde toepassingen;
    // dan kan je de gevaarlijke getter achterwege laten.
    // (Strings zijn immutable objects; daar krijg je dus automatisch een kopie van.)
    public String geefNaamDocent(){
        return titularis.getVoornaam()+" "+titularis.getAchternaam();
    }
    
    
    // Heeft 'Student' een hashCode (en equals)?
    // Anders zal onderstaande methode niet het gewenste effect hebben.
    public void voegStudentToe(Student student) throws FoutBijInschrijving{
        studenten.add(student);
        if(!student.getCurriculum().contains(this)){
            student.schrijfInVoorVak(this);
        }
    }
    // MERK OP
    // Omdat we 'dubbele informatie' bijhouden
    // (een student houdt verwijzingen bij naar zijn cursussen;
    //   een cursus houdt verwijzingen bij naar zijn studenten)
    // is het belangrijk om ervoor te zorgen dat alle informatie goed
    // op elkaar afgestemd is. 
    // Bij databanken noemt dit afstemmen "normaliseren van de databank";
    // dat is een cursus op zich.
    // VOORDELEN VAN DUBBELE INFORMATIE BIJHOUDEN:
    //    - zaken zijn sneller opgezocht 
    //      (waar het bij databanktoepassingen dikwijls om draait)
    // NADELEN  VAN DUBBELE INFORMATIE BIJHOUDEN:
    //    - meer geheugenplaats nodig (al is het enkel voor 'referenties naar',     
    //                                 de objecten zelf worden niet dubbel bewaard)
    //    - beter opletten bij toevoegen van informatie
    
    public int getAantalStudiepunten() {
        return aantalStudiepunten;
    }
    
    public String getNaam(){
        return naam;
    }

    // Implementatie van hashCode en equals zijn ZEKER nodig,
    // anders zou een student zich tien keer voor dezelfde cursus
    // kunnen inschrijven; de hashSet 'curriculum' van de klasse 'Student'
    // zou niet doorhebben dat het om eenzelfde cursus gaat.
    //
    // In jullie oplossing werd er allicht voor naam, studiejaar en aantalStudiepunten
    // gekozen. Is prima.
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + Objects.hashCode(this.naam);
        hash = 59 * hash + Objects.hashCode(this.cursuscode);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cursus other = (Cursus) obj;
        if (!Objects.equals(this.naam, other.naam)) {
            return false;
        }
        if (!Objects.equals(this.cursuscode, other.cursuscode)) {
            return false;
        }
        return true;
    }
    
    
    @Override
    public String toString(){
        String str = naam + " ("+studiejaar+"e jaar; "+aantalStudiepunten+" studiepunten; titularis ";
        if(titularis == null){
            str += "null; "+studenten.size()+" studenten)";
        }
        else{
            str += titularis.getAchternaam()+"; "+studenten.size()+" studenten)";
        }
        return str;
    }
    
    
    @Override
    public Cursus clone(){
        try {
            return (Cursus)super.clone();
        } catch (CloneNotSupportedException ex) {
            return null;
        }
    }
}
