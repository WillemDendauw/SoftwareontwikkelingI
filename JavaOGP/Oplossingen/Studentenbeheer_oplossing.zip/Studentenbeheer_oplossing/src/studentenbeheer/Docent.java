package studentenbeheer;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author tiwi
 */
public class Docent extends Persoon{
    private Set<Cursus> cursussen;

    public Docent(String voornaam, String naam){
        super(voornaam,naam,null,0,null,null);
        cursussen = new HashSet();
    }
    
    public Docent(Docent andereDocent){
        super(andereDocent);
        cursussen = new HashSet();
        for(Cursus cursus : andereDocent.cursussen){
            cursussen.add(cursus.clone());
        }        
    }
        
    public void addCursus(Cursus cursus){
        cursussen.add(cursus);
        if(!this.equals(cursus.getDocent())){ // draai de operandi niet om; NullPointerException!!
            cursus.setDocent(this);
        }
    }
    
    // hier wordt een kopie van de cursussen teruggegeven
    public Cursus[] getCursussen(){        
        Cursus[] cc = new Cursus[cursussen.size()];
        int i=0;
        for(Cursus c : cursussen){
            cc[i++] = c.clone();
        }
        return cc;  
    }
    // Indien je een ondiepe kopie van de cursussen wil teruggeven, dan zou je
    //     return cursussen.toArray(new Cursus[0]);
    // schrijven.
    
    
    public boolean geeftCursus(Cursus c){
        return cursussen.contains(c);
    }
    
    @Override
    public String toString(){
        String str = "docent " + super.toString() +" ";
        for(Cursus c : cursussen){
            str += c.getNaam()+" / ";
        }
        return str;
    }

}
