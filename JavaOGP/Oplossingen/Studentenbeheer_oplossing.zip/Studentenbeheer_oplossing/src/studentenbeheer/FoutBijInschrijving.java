package studentenbeheer;

/**
 *
 * @author tiwi
 */
public class FoutBijInschrijving extends Exception {

    public FoutBijInschrijving(String s) {
        super(s);
    }
    
}
