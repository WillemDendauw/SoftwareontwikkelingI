package studentenbeheer;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

/**
 *
 * @author tiwi
 */
public class Persoon implements Serializable {

    private final String voornaam;
    private final String achternaam;
    private String adres;
    private int postcode;
    private String gemeente;
    private final Date geboortedatum;

    public Persoon(String voornaam, String naam, String adres, int postcode, String gemeente, Date geboortedatum) {
        this.voornaam = voornaam;
        this.achternaam = naam;
        this.adres = adres;
        this.postcode = postcode;
        this.gemeente = gemeente;
        
        // Hier wordt de parameter Date gekloond. Omdat 'geboortedatum' een object
        // is, moet je afwegen wat je wil:
        // -  als je zeker misbruik van de constructor wil vermijden 
        //    (in de unittest 'testConstructorPersoon' proberen we dit misbruik uit),
        //    dan moet je van elke parameter een kloon maken
        //    (behalve voor parameters van primitieve types of immutable objects.)
        // -  in de praktijk merk je dat het aanpassen van een datum niet evident is
        //    (je moet al via getTime() en setTime()), dus zaken 'per ongeluk' aanpassen
        //    zal niet snel gebeuren.
        if (geboortedatum == null) {
            this.geboortedatum = null;
        } else {
            this.geboortedatum = (Date) geboortedatum.clone();
        }
    }

    public Persoon(Persoon p) {
        this(p.voornaam, p.achternaam, p.adres, p.postcode, p.gemeente, p.geboortedatum);
    }

    public String getVoornaam() {
        return voornaam;
    }

    public String getAchternaam() {
        return achternaam;
    }

    // Stond niet in de opgave; toegevoegd
    // om een extra test te laten lopen (zie unittest 'testConstructorPersoon').
    public Date getGeboortedatum() {
        return (Date) geboortedatum.clone();
    }

    @Override
    public String toString() {
        return voornaam + " " + achternaam;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 11 * hash + Objects.hashCode(this.voornaam);
        hash = 11 * hash + Objects.hashCode(this.achternaam);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Persoon other = (Persoon) obj;
        if (!Objects.equals(this.voornaam, other.voornaam)) {
            return false;
        }
        if (!Objects.equals(this.achternaam, other.achternaam)) {
            return false;
        }
        return true;
    }

}
