package studentenbeheer;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author tiwi
 */
public class Student extends Persoon {

    private Set<Cursus> curriculum;
    // Bewaarde je ook het aantal studiepunten?
    // Let op met het dubbel bewaren van informatie! 
    // (Uit het curriculum kan het aantal studiepunten ook afgeleid worden,
    // dus dubbele info.)
    // Eens de dubbele informatie gecorrumpeerd is, krijg je dat nooit meer goed!

    public final static int MAXAANTALSTUDIEPUNTEN = 20;  // eigenlijk 60; voor testdoeleinden lager!!

    public Student(String voornaam, String naam, String adres, int postcode, String gemeente, Date geboortedatum) {
        super(voornaam, naam, adres, postcode, gemeente, geboortedatum);
        curriculum = new HashSet();
    }
    
    // De kopieconstructor maakt een diepe kopie,
    // dus ook van alle cursussen zal een kopie gemaakt worden.
    // Gebruik de kopieconstructor dus NIET IN de klasse StudentenDAO,
    // want dan eindig je met veel te veel kopies van cursussen.
    // (Bekijk de opmerking in StudentenDAO over de 30 + 15 + 200 objecten.)
    // De kopieconstructor zal alleen nuttig zijn bij het schrijven van 
    // de getter-methodes in StudentenDAO:
    //    getStudent(...)
    //    getDocent(...)
    //    getCursus(...)
    // maar die methodes worden niet INTERN in de klasse StudentenDAO
    // opgeroepen; die zijn er enkel ten behoeve van de gebruikers 
    // van de klasse StudentenDAO.
    public Student(Student andereStudent){
        super(andereStudent);
        curriculum = new HashSet();
        for(Cursus cursus : andereStudent.curriculum){
            curriculum.add(cursus.clone());
        }
    }

    public void schrijfInVoorVak(Cursus cursus) throws FoutBijInschrijving {
        // Indien curriculum dit vak al bevat, of totaal aantal studiepunten
        // overschreden zou worden: niet inschrijven maar fout opwerpen.
        // De vraag 'contains' impliceert natuurlijk dat je de methode
        // 'equals' hebt voor de klasse Cursus (en dus ook de methode hashCode).
        if (curriculum.contains(cursus)) {
            throw new FoutBijInschrijving("al ingeschreven voor vak " + cursus.getNaam());
        }
        int puntenCursus = cursus.getAantalStudiepunten();
        int puntenReedsOpgenomen = this.getAantalStudiepunten();
        if (puntenCursus + puntenReedsOpgenomen > MAXAANTALSTUDIEPUNTEN) {
            throw new FoutBijInschrijving("aantal studiepunten is al "
                    + puntenReedsOpgenomen + "; daar kunnen er geen "
                    + puntenCursus + " meer bij.");
        }
        curriculum.add(cursus);
        cursus.voegStudentToe(this); // zorg in de methode 'voegStudentToe' dat er geen
        // oneindige loop mogelijk is
    }

    // Hieronder werd gekozen om het returntype te veranderen van Cursus[] (zie gegeven klassendiagram)
    // naar Set<Cursus>. Dat zijn ontwerpbeslissingen, die jullie misschien anders genomen hebben.
    //
    // Omdat we willen vermijden dat er via deze weg aan de cursussen geprutst kan
    // worden (bvb. setDocent(...)), geven we hier een set van kopies terug.
    // Ook weer een ontwerpbeslissing die je misschien anders nam; 
    // maar oefen je zeker in het teruggeven van kopies van objecten!
    public Set<Cursus> getCurriculum() {
        Set<Cursus> kopie = new HashSet<>();
        for (Cursus c : curriculum) {
            kopie.add(c.clone());
        }
        return kopie;
    }

    public int getAantalStudiepunten() {
        int pt = 0;
        for (Cursus c : curriculum) {
            pt += c.getAantalStudiepunten();
        }
        return pt;
    }

    @Override
    public String toString() {
        String str = "";
        for (Cursus c : curriculum) {
            str += c.getNaam() + " -";
        }
        return "student " + super.toString() + str;
    }

    // Geen hashCode en equals nodig; 
    // je erft die van de bovenklasse over.
    // Een Docent met naam Jef Klaassen en een Student met naam Jef Klaassen
    // zullen als verschillende Persoon herkend worden!
    // (Ga na...)
}
