package studentenbeheer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author tiwi
 */
public class StudentenDAO implements Serializable {
// DAO staat voor Data Access Object;
// deze klasse geeft je toegang tot verschillende objecten tegelijk.
//    
// LET OP!
// Het is de bedoeling dat een object van deze klasse 
//     van elke student slechts één exemplaar bewaart;
//     van elke docent slechts één exemplaar bewaart;
//     van elke cursus slechts één exemplaar bewaart.
// Dus als er 200 studenten, 15 docenten en 30 cursussen zijn,
// dan zal er slechts 200 + 15 + 30 keer een 'new' object van de gepaste
// klasse gecreëerd worden en in de instantievariabelen (drie mappen)
// bewaard worden.
//
// De onderlingen relaties tussen studenten, cursussen en docenten
// worden dan door middel van REFERENTIES (verwijzingen) gelegd;
// NIET door een kopie van objecten te creëren.
//
// Merk op dat de getters wel kopieën creëren, maar dat hoort ook zo voor 
// een getter. Een buitenstaander zou anders aan de cruciale interne informatie
// wijzigingen kunnen aanbrengen.
//
// Maar dan moet je wel opletten bij het hoofdprogramma.
// Als je een student wenst in te schrijven voor een vak (bvb Wiskunde I), 
// en dus daarvoor eerst de student opvraagt aan het DAO-object
// om de student in te schrijven voor die cursus, dan zal er intern in het DAO-object
// niets gewijzigd zijn (je werkt immers met een KOPIE van de student en allicht
// ook met een kopie van de cursus, als je die via getter verkreeg). 
// Beter: je geeft het DAO-object de opdracht een bepaalde
// student in te schrijven voor een bepaalde cursus.
// Dat vraagt dus een extra methode, die nog niet voorzien was in het klassendiagram.    
    
    private Map<String, Student> studenten; // voornaam+" "+naam als key !!
    private Map<String, Docent> docenten;
    private Map<String, Cursus> cursussen;

    public StudentenDAO(String bestandMetCursussen) throws FileNotFoundException {
        studenten = new HashMap<>();
        docenten = new HashMap<>();
        cursussen = new HashMap<>();

        Scanner sc = new Scanner(new File(bestandMetCursussen));
        while (sc.hasNext()) {
            String regel = sc.nextLine();
            //System.out.println("REGEL "+regel); // methode om fouten te vinden
            // bij inlezen van bestand !!!
            // nl. SCHRIJF UIT WAT JE INLEEST.
            Scanner sc2 = new Scanner(regel);
            sc2.useDelimiter(";");
            int jaar = sc2.nextInt();
            String titel = sc2.next();
            String naamTitularis = sc2.next();
            int aantalPtn = sc2.nextInt();
            String code = sc2.next();
            Cursus cursus = new Cursus(titel, jaar, aantalPtn, code);
            int plaatsSpatie = naamTitularis.indexOf(" ");
            Docent docent = new Docent(naamTitularis.substring(0, plaatsSpatie).trim(),
                    naamTitularis.substring(plaatsSpatie).trim());

            if (!docenten.containsKey(naamTitularis.toLowerCase().trim())) {
                docenten.put(naamTitularis.toLowerCase().trim(), docent);
            }
            docenten.get(naamTitularis.toLowerCase().trim()).addCursus(cursus);

            if (!cursussen.containsKey(titel)) {
                cursussen.put(titel, cursus);
            }
            cursussen.get(titel).setDocent(docenten.get(naamTitularis.toLowerCase().trim()));

        }

    }

    public Student getStudent(String naam) {
        Student st = studenten.get(naam.toLowerCase().trim());
        if(st == null){
            return null;
        }
        return new Student(st);
    }

    public Docent getDocent(String naam) {
        Docent d = docenten.get(naam.toLowerCase().trim());
        if(d == null){
            return null;
        }
        return new Docent(d);
    }

    public Cursus getCursus(String naam) {
        return cursussen.get(naam).clone();
    }

    public Cursus[] getCursussenVanDocent(String naam) {
        Docent d = docenten.get(naam.toLowerCase().trim());
        Cursus[] c = d.getCursussen(); // dit bevat al een kopie van de cursussen
        return c;
    }

    public void addStudent(Student student) {
        studenten.put((student.getVoornaam() + " " + student.getAchternaam()).toLowerCase(), student);
    }
    
    public void schrijfStudentInVoorCursus(String studentenNaam, String cursusNaam) throws FoutBijInschrijving{
        if(!studenten.containsKey(studentenNaam)){
            throw new FoutBijInschrijving("student met naam "+studentenNaam+" niet gevonden.");
        }
        if(!cursussen.containsKey(cursusNaam)){
            throw new FoutBijInschrijving("cursus met naam "+cursusNaam+" niet gevonden.");
        }
        studenten.get(studentenNaam).schrijfInVoorVak(cursussen.get(cursusNaam));
    }

    // zorgt dat alle cursusnamen onder elkaar weergegeven worden;
    // is nuttig in het hoofdprogramma
    public String getCursussenToString() {
        String antwoord = "";
        for (String str : cursussen.keySet()) {
            antwoord += str + "\n";
        }
        return antwoord;
    }

    @Override
    public String toString() {
        String str = "DOCENTEN";
        for (String docent : docenten.keySet()) {
            str += "\n" + docent + " ---> " + docenten.get(docent);
        }
        str += "\nSTUDENTEN";
        for (String st : studenten.keySet()) {
            str += "\n" + st + " ---> " + studenten.get(st);
        }
        str += "\nVAKKEN";
        str += ("-----------size van cursussen is " + cursussen.size());
        for (String st : cursussen.keySet()) {
            str += "\n" + st + " ---> " + cursussen.get(st);
        }
        return str;
    }

}
