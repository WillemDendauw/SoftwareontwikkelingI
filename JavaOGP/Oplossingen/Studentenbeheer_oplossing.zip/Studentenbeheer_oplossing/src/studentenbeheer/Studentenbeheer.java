package studentenbeheer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Studentenbeheer {

    private static StudentenDAO dao;
    private static Scanner sc = new Scanner(System.in);

    // De code die hieronder staat, voorziet nog wat extra's;
    // nl. de gebruiker geeft op de commandolijn weer of hij wil
    // 'resetten' (alle vorige geserialiseerde gegevens worden gewist, en er wordt
    //             opgestart vanaf het tekst-bestand dat de gebruiker meegeeft
    //             op diezelfde commandolijn).
    // Indien de gebruiker niets ingeeft op de commandolijn, wordt er
    // voortgewerkt op de geserialiseerde gegevens uit de vorige run van
    // het programma.
    public static void main(String[] args) {
        
        dao = null;
        try {
            if (args.length > 1 && args[0].equalsIgnoreCase("reset")) {
                System.out.println("Ik reset het programma, en start vanaf het bestand " + args[1] + ".");
                initialiseerDAO(true, args[1]);
            } else if (args.length == 0) {
                System.out.println("Ik ga voort met de gegevens die ik opsloeg na de vorige run van het programma.");
                initialiseerDAO(false, "");
            }

            overlegMetGebruiker();  // het eigenlijke programmaverloop

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            if (dao != null) {
                try {
                    schrijfGeserialiseerdeVersieWeg();
                } catch (IOException ex) {
                    System.out.println("Iets foutgelopen bij het wegschrijven van alle gegevens... een volgende run kan problemen opleveren :-/");
                }
            }
        }

    }

    public static void overlegMetGebruiker() {
        int keuze = toonMenu();
        while (keuze != 4) {
            if (keuze == 1) {
                docentZoeken();
            } else if (keuze == 2) {
                studentZoeken();
            } else if (keuze == 3) {
                studentInschrijven();
            }
            keuze = toonMenu();
        }
        sc.close();
    }

    private static void initialiseerDAO(boolean reset, String bestandsnaam) throws FileNotFoundException, Exception {

        // twee mogelijkheden: 
        // (1) 'reset' door bestand met cursussen en docenten in te lezen,
        // (2) geserialiseerde StudentenDAO uit bestand halen                 
        if (reset) {
            dao = new StudentenDAO(bestandsnaam);
        } else {
            leesGeserialiseerdeVersieIn();
        }
    }

    private static void leesGeserialiseerdeVersieIn() throws Exception {
        try {
            File opslag = new File("studentenDAOopslagplaats.txt");
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(opslag));
            dao = (StudentenDAO) in.readObject();
        } catch (IOException ex) {
            throw new Exception("Je vraagt me niet om te resetten (commandolijn zou dan 'reset bestandsnaam.txt' bevatten), "
                    + "\nmaar er liep iets mis met de opslag van vorige runs...\n"+ex.getMessage());
        } catch (ClassNotFoundException ex) {
            throw new Exception("Je vraagt me niet om te resetten (commandolijn zou dan 'reset bestandsnaam.txt' bevatten), "
                    + "\nmaar er liep iets mis met de opslag van vorige runs...\n"+ex.getMessage());
        }
    }

    private static void schrijfGeserialiseerdeVersieWeg() throws IOException {
        File opslag = new File("studentenDAOopslagplaats.txt");
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(opslag))) {
            out.writeObject(dao);
        }
    }

    private static String vraagInfo(String boodschap){
        System.out.println(boodschap+": ");
        return sc.nextLine();
    }
    
    private static Date vraagGeboortedatum(){
        Date datum;
        String datumString = vraagInfo("Geboortedatum (dd-MM-yyyy)");
        try {
            datum = new SimpleDateFormat("dd-MM-yyyy").parse(datumString);
        } catch (ParseException ex) {
            System.out.println("Verkeerde geboortedatum");
            datum = vraagGeboortedatum();
        }
        return datum;
    }
    
    private static void studentInschrijven() {
        System.out.println("Deel I: Personalia");
        System.out.println("");
        
        String voornaam = vraagInfo("Voornaam");
        String naam = vraagInfo("Naam");

        Student student = dao.getStudent(voornaam + " " + naam); // Dit is een kopie;
                   // werk niet verder met methodes van deze student als je
                   // hem/haar wil inschrijven! Stel de vraag aan dao!!
                   // Dit zal je enkel merken als je een student eerst inschrijft voor
                   // twee vakken, terugkeert naar het keuzemenu,
                   // en nadien diezelfde student wil inschrijven voor
                   // nog een extra vak. Dat extra vak zal nooit in zijn curriculum
                   // verschijnen als je met deze kopie verder werkt.

        // enkel indien de student nog niet in het systeem zat, worden
        // zijn gegevens opgevraagd
        if (student == null) {
            Date geboortedatum = vraagGeboortedatum();
            String adres = vraagInfo("Adres");
            String strPostcode = vraagInfo("Postcode");
            int postcode = -1;
            while (postcode == -1) {
                try {
                    postcode = Integer.parseInt(strPostcode); // zou je in methode moeten verpakken!
                    if (postcode != 0 && !(postcode >= 1000 && postcode <= 9999)) {
                        postcode = -1;
                        throw new NumberFormatException();
                    }
                } catch (NumberFormatException e) {
                    strPostcode = vraagInfo("Postcode (0 indien onbekend)");
                }
            }
            String gemeente = vraagInfo("Gemeente");
            student = new Student(voornaam, naam, adres, postcode, gemeente, geboortedatum);
            dao.addStudent(student);
        }
        System.out.println("");
        System.out.println("Deel II: Curriculum");
        String cursusNaam = vraagInfo("Geef de naam van een cursus (lege string om te stoppen)");
        while (!cursusNaam.equals("")) {
            Cursus cursus = dao.getCursus(cursusNaam);
            if (cursus != null) {
                try {
                    //student.schrijfInVoorVak(cursus); //'student' is een kopie; dus dit gaat niets uithalen!
                    dao.schrijfStudentInVoorCursus(voornaam+" "+naam,cursusNaam);
                } catch (FoutBijInschrijving e) {
                    System.out.println(e.getMessage());
                }
            } else {
                System.out.println("Deze cursus bestaat niet; dus inschrijving ging niet door.");
                System.out.println("Kies uit: " + dao.getCursussenToString());
            }            
            cursusNaam = vraagInfo("Geef de naam van een cursus (lege string om te stoppen)");
        }

    }

    private static void studentZoeken() {
        String naam = vraagInfo("Geef de naam van een student (voornaam spatie achternaam)").trim().toLowerCase();
        Student student = dao.getStudent(naam);
        if (student != null) {
            System.out.println(naam + " is ingeschreven voor:");
            for (Cursus oo : student.getCurriculum()) {
                System.out.println(oo.getNaam());
            }
        } else {
            System.out.println("Deze student werd niet gevonden; onze excuses.");
        }
    }

    private static int toonMenu() {
        System.out.println("\n\nMaak een keuze:");
        System.out.println("");
        System.out.println("1. een docent zoeken");
        System.out.println("2. een student zoeken");
        System.out.println("3. een student inschrijven");
        System.out.println("4. stoppen");
        System.out.print("\nKeuze:  ");
        Scanner sc = new Scanner(System.in);
        int keuze;
        try{
            keuze = sc.nextInt();
        }
        catch(InputMismatchException e){
            System.out.println("Verkeerde invoer ("+e.getMessage()+"): ");
            keuze = toonMenu();
        }
        return keuze;
    }

    private static void docentZoeken() {
        String naam = vraagInfo("Geef de naam van een docent (voornaam, spatie, achternaam)").trim().toLowerCase();
        Docent docent = dao.getDocent(naam);
        if (docent != null) {
            System.out.println(naam + " geeft de volgende cursussen: ");
            for (Cursus cursus : docent.getCursussen()) {
                System.out.println(cursus.getNaam());
            }
        } else {
            System.out.println("Deze docent werd niet gevonden; onze excuses.");
        }
    }

}
