import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import studentenbeheer.*;
import java.util.Date;

/**
 *
 * @author tiwi
 */
public class Testcases {
    
    public Testcases() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    @Test
    public void testBestandInlezenSpecifiekeCursus() throws FileNotFoundException {
        StudentenDAO dao = new StudentenDAO("cursussen.txt");
        Cursus c = dao.getCursus("Signalen en systemen");
        assertEquals("cursus 'Signalen en systemen' niet ingelezen?","Signalen en systemen",c.getNaam());
        assertEquals("cursus 'Signalen en systemen' niet ingelezen?",6,c.getAantalStudiepunten());
    }
    
    @Test
    public void testBestandInlezenAlleCursussen() throws FileNotFoundException {
        StudentenDAO dao = new StudentenDAO("cursussen.txt");
        int lengteAlleCursusnamen = dao.getCursussenToString().length();
        assertTrue("cursusnamen allemaal juist?", 490 <= lengteAlleCursusnamen && lengteAlleCursusnamen <= 580);
    }
    // Opmerking: bovenstaande test is maar flauwtjes en bovendien niet waterdicht.
    // Omdat er niet gespecifieerd werd wat er precies in 'getCursussenToString()' moet komen,
    // kan hier wat 'rek' zitten op het resultaat.

    @Test
    public void testDocentZoekenOpNaam() throws FileNotFoundException {
        StudentenDAO dao = new StudentenDAO("cursussen.txt");
        Docent docentGevonden = dao.getDocent("Joris Moreau");
        Docent docentGezocht = new Docent("Joris", "Moreau");
        assertEquals("Docent werd niet herkend op naam en voornaam.", docentGezocht, docentGevonden);
    }
    
    @Test
    public void testInfoCursussenEnDocentenGelinkt() throws FileNotFoundException {
        StudentenDAO dao = new StudentenDAO("cursussen.txt");
        Cursus[] cursussen = dao.getCursussenVanDocent("Joris Moreau");
        assertEquals("docent is cursussen kwijt?",4,cursussen.length);
    }
    
    @Test
    public void testBeveiliging() throws FileNotFoundException {
        StudentenDAO dao = new StudentenDAO("cursussen.txt");
        Cursus[] cursussen = dao.getCursussenVanDocent("Paul Devos");
        assertEquals("docent Paul Devos geeft 1 cursus",1,cursussen.length);
        cursussen[0].setDocent(new Docent("Anonymous","Ickx"));
        Cursus[] cursussenNaAanpassing = dao.getCursussenVanDocent("Paul Devos");
        String docentVanCursusVanPaulDevos = cursussenNaAanpassing[0].getDocent().getAchternaam();
        assertEquals("docent Paul Devos gaf 1 cursus - na aanpassing niet meer?","Devos",docentVanCursusVanPaulDevos);        
    }
    
    @Test
    public void testConstructorPersoon() throws ParseException{
        Date datum = new SimpleDateFormat("dd-MM-yyyy").parse("12-12-1634");
        Persoon j = new Persoon("Jan","Klaassen","Mookerhei 13",6500,"Nijmegen",datum);
        // We vervroegen de datum met een jaar:
        long milliseconden = datum.getTime();
        long sec = 365*24;
        sec *= 60*60;
        sec *= 1000;
        // Schrijf niet "milliseconden - 365*24*60*60*1000", want het resultaat
        // van dat product levert overflow (is type int).
        // Zorg dat je met type long werkt.
        datum.setTime(milliseconden - sec);
        // Historische noot: moedwillige contaminatie van historische figuren.
        // En moedwillig hergebruik van object 'datum'.
        Persoon k = new Persoon("Katrijn","Pieters","Jordaan",1050,"Amsterdam",datum);
        assertNotEquals(j.getGeboortedatum(),k.getGeboortedatum());
    }
    
}
